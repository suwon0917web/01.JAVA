package shoppingMall;

public class Calculator {
	public int process(int n) {
		return n*n;
	}	
}
