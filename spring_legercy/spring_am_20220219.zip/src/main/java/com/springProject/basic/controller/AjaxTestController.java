package com.springProject.basic.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.springProject.basic.service.BookService;

@Controller
public class AjaxTestController {
	private static final int PERCOUNT = 10;
	@Autowired
	BookService bookService;
	
	
	@RequestMapping(value = "/ajaxtest", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView mv = new ModelAndView("ajax/test1");
		return mv;
	}
	
	@RequestMapping(value = "/ajaxtestdb", method = RequestMethod.GET)
	public ModelAndView ajaxtestdb() {
		ModelAndView mv = new ModelAndView("ajax/test2_fromdb");
		return mv;
	}
	
	@ResponseBody
	@RequestMapping(value = "/ajaxtest2")
	public JSONArray ajaxTest(String data) {
		System.out.println(data);
		JSONArray jsonarray = new JSONArray();
		ObjectMapper mapper = new ObjectMapper();
		try {			
			jsonarray = mapper.readValue(data, JSONArray.class);
			for (int i = 0; i < jsonarray.size(); i++) {
				HashMap ja =  (HashMap) jsonarray.get(i);
				System.out.println(ja.get("num")+" " + ja.get("score"));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(jsonarray.get(0));
		return jsonarray;
	}
	
	
	@RequestMapping(value = "/ajaxbooklist")
	public @ResponseBody JSONArray ajaxbooklist(String data) {
		JSONArray jsonarray = new JSONArray();
		ObjectMapper mapper = new ObjectMapper();
		JSONArray obj = new JSONArray();
		try {
			jsonarray = mapper.readValue(data, JSONArray.class);
			HashMap ja =  (HashMap) jsonarray.get(0);
			int start = (int)ja.get("page");
			
			if(start == 1) {
				start = 0;
			}else {
				start = (start-1)*PERCOUNT+1;
			}
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("start", start);		
			map.put("end", PERCOUNT);
			
			List<Map<String, Object>> lists = bookService.lists(map);
			
			// 검색조건에 대한 전체 데이터 건수
			int totalSize = bookService.totalcount(map);		  
			int pageCount = totalSize / PERCOUNT;
			if(totalSize % PERCOUNT != 0) {
				pageCount++;
			}		
			// lists와 pageCount를 리턴			
			obj.add(lists);
			obj.add(pageCount);
		} catch (Exception e) {			
			e.printStackTrace();
		}
		return obj;	
	}
}
