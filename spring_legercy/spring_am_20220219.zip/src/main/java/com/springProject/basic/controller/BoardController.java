package com.springProject.basic.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileUploadException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.springProject.basic.service.BoardService;
import com.springProject.basic.service.FileUpDwonload;
import com.springProject.basic.vo.BoardVo;
import com.springProject.basic.vo.CommentVo;
import com.springProject.basic.vo.FileInfoVo;

@Controller
public class BoardController {

	@Autowired
	ServletContext sc;
	
	@Autowired  // 생성된 bean(스프링 컨테이너가 만들어주는 객체)을 연결해 주는 어노테이션
	BoardService boardService;
	
	// 게시판 상세조회
	@RequestMapping(value = "/board2", method = RequestMethod.GET)
	public ModelAndView board2() {
		// 게시글 조회
		
		// 선택된 게시글의 뎃글 목록
		int boardId = 1;
		List<CommentVo> replys = boardService.selectComment(boardId);
		
		ModelAndView mv = new ModelAndView("board/board2");
		mv.addObject("replys", replys);
		return mv;
	}
	
	@RequestMapping(value = "/board", method = RequestMethod.GET)
	public ModelAndView board() {
		ModelAndView mv = new ModelAndView("board/board");
		List<BoardVo> boardlist = boardService.getBoardList();
//		String realPath = sc.getRealPath("/resources/upload");	// 실제 저장될 서버의 경로이지만	
//		mv.addObject("root", realPath); 					    view에서는 servlet-context.xml에 있는 정보를 가지고 셋팅한다. 			
		mv.addObject("boardlist", boardlist);
		return mv;
	}
	// 게시판 작성 화면 호출
	@RequestMapping(value = "/boardwrite", method = RequestMethod.GET)
	public ModelAndView boardwrite() {
		List<BoardVo> boardlist = boardService.getBoardList();		
		ModelAndView mv = new ModelAndView("board/boardwrite");		
		return mv;
	}
	
	// 게시판 작성 후 게시판 화면으로 돌아감
//	@RequestMapping(value = "/boardwrite", method = RequestMethod.POST)
//	public ModelAndView boardwritePoist(
//			BoardVo vo,
//			@RequestParam("uploadfile") MultipartFile file
//			 ) throws FileUploadException, IllegalStateException, IOException {				
//		if(file != null) {
//			String saveFilePath = "C:\\upload\\";  // 저장할 경로
//			String originFileName = file.getOriginalFilename(); // 파일경로포함 업로할 파일
//			String pattern = Pattern.quote(System.getProperty("file.separator")); // 파일경로 분리 태그			
//			String[] splitFileName =   originFileName.split(pattern);	// 디렉터리기준으로 분리		
//			
//			int lastIndex = splitFileName.length-1; // 마지막 인덱스(파일명및 확장자)
//			String fileName = splitFileName[lastIndex];
//			
//			//to file save
//			File f = new File(saveFilePath+fileName); // 저장경로
//			file.transferTo(f); // 저장
//		}
//		ModelAndView mv = new ModelAndView("board/boardwrite");
//		return mv;
//	}
	@RequestMapping(value = "/boardwrite", method = RequestMethod.POST)
	public ModelAndView boardwritePoist(
			BoardVo vo,	HttpSession session,		
			@RequestParam("uploadfile") MultipartFile[] file
			 ) throws FileUploadException, IllegalStateException, IOException {
		
		String loginId = (String)session.getAttribute("loginId");
		if(loginId == null || loginId.isBlank()) {
			ModelAndView mv = new ModelAndView("redirect:/login");
			return mv;
		}
		
		vo.setB_id(loginId);
		int id = boardService.insert(vo);
		
		List<FileInfoVo> savedFileNames =  FileUpDwonload.saveFileFromUI(sc, file, vo.getB_no());
		boardService.fileInsert(savedFileNames);
		
		ModelAndView mv = new ModelAndView("redirect:/board");
		return mv;
	}	
	
}
