package com.springProject.basic.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springProject.basic.vo.BookVo;

@Repository
public class BookDao {
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public int insert(Map<String, Object> map) {
		return sqlSessionTemplate.insert("book.insert",map);
	}
	
	public BookVo selectbyid(Map<String, Object> map){
		return sqlSessionTemplate.selectOne("book.selectbyid",map);
	}

	public void update(Map<String, Object> map) {
		sqlSessionTemplate.update("book.update", map);
		
	}

	public List<Map<String, Object>> getlists() {		
		return sqlSessionTemplate.selectList("book.lists");
	}

	public List<Map<String, Object>> getlists(Map<String, Object> map) {	
		System.out.println(map);
		return sqlSessionTemplate.selectList("book.listsWithParam", map);
	}

	public void deleteById(Map<String, Object> map) {
		sqlSessionTemplate.delete("book.deleteById", map);
		
	}

	public int totalcount(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return (int)sqlSessionTemplate.selectOne("book.totalcount", map);
	}


}