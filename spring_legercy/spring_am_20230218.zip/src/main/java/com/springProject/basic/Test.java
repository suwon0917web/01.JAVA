package com.springProject.basic;

import java.util.HashMap;
import java.util.Map;

public class Test {
	public static void addMapData(Map<String, Object> map) {
		map.put("book_id", "123456789");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		System.out.println(map);
		
		addMapData(map);
		
		System.out.println(map);
	}

}
