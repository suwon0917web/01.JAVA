package com.springProject.basic.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.view.AbstractView;

import com.springProject.basic.vo.FileInfoVo;

public class FileUpDwonload extends AbstractView{
	public static List<FileInfoVo> saveFileFromUI(ServletContext servletContext, 
			MultipartFile[] file, Integer id) throws IOException {
		String realPath = servletContext.getRealPath("/resources/upload");		
		System.out.println("realPath : "+realPath);
		String today = new SimpleDateFormat("yyMMdd").format(new Date());
		String saveFolder = realPath+File.separator+today;
		System.out.println("today : "+today);
		System.out.println("saveFolder : "+saveFolder);
		File folder = new File(saveFolder);
		if(!folder.exists()) // 저장 경로가 없으면 생성해 준다.
			folder.mkdir();
		
		List<FileInfoVo> savedFilenames = new ArrayList<FileInfoVo>();
		
		for (MultipartFile mfile : file) {
			String oriFName = mfile.getOriginalFilename();
			if(!oriFName.isBlank()) {
				String saveFileName = UUID.randomUUID().toString() 
						+ oriFName.substring(oriFName.lastIndexOf('.'));
				System.out.println("saveFileName : "+saveFileName);
				mfile.transferTo(new File(folder, saveFileName));
				
				FileInfoVo fileVo = new FileInfoVo();
				fileVo.setF_realFileName(oriFName);
				fileVo.setF_fileName(saveFileName);
				fileVo.setF_path(saveFolder);
				fileVo.setB_no(id);
				
				savedFilenames.add(fileVo);
			}
		}
		return savedFilenames;
	}

	
	public FileUpDwonload() {
		setContentType("application/download; charset=UTF-8");
	}


	@Override
	protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ServletContext ctx =  getServletContext();
		String realPath = ctx.getRealPath("/resources/upload");
		File file = new File(realPath+"/230212/f6532d7a-9327-4088-ac19-e6c3be87e91d.jfif");
		response.setContentType(getContentType());
		response.setContentLength((int)file.length());
		
		String header = request.getHeader("User-Agent");
		boolean isIE = header.indexOf("MSIE") > -1 || header.indexOf("Trident") > -1;
		String fileName = null;
		if(isIE) {
			fileName = URLEncoder.encode("filedownload","UTF-8").replaceAll("\\+", "%20");
		}else {
			fileName = new String("filedownload".getBytes("UTF-8"),"ISO-8859-1");
		}
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\";");
        response.setHeader("Content-Transfer-Encoding", "binary");
        OutputStream out = response.getOutputStream();
        FileInputStream fis = null;        
        try {
            fis = new FileInputStream(file);
            FileCopyUtils.copy(fis, out);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(fis != null) {
                try { 
                    fis.close(); 
                }catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        out.flush();
	}
}
