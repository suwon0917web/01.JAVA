package com.springProject.basic.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springProject.basic.service.BookService;
import com.springProject.basic.vo.BookVo;

@Controller
public class BookController {

	private static final Logger logger = LoggerFactory.getLogger(BookController.class);

	private static final int PERCOUNT = 5;
	
	@Autowired
	BookService bookService;
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView mv = new ModelAndView("book/create");
		return mv;
	}
	
	// 브라우져로부터 url형식으로 요청을 받으면 모델을 호출하는 메소드
	// 모델 : bookService
	// url : insert method : post
	@RequestMapping(value = "/insert"
			, method = RequestMethod.POST
			)
	public ModelAndView insertBook(@RequestParam Map<String, Object> map) {
		ModelAndView mv = new ModelAndView();
		// model 호출(실제이름은 ooooservice)
		String book_id =  bookService.insert(map);
		if(book_id != null)
			mv.setViewName("redirect:/detail?book_id="+book_id);
		else
			mv.setViewName("book/create");
		return mv;
	}
	/*
	@RequestMapping(value = "/detail", method = RequestMethod.GET)
//	public ModelAndView detail(@RequestParam(value = "book_id") String id) 
	public ModelAndView detail(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView("/book/detail");
//		mv.addObject("book_id", id);
		mv.addObject("book_id", request.getParameter("book_id"));
		return mv;
	}
	*/
	
	@RequestMapping(value = "/detail", method = RequestMethod.GET)
	public ModelAndView selectbyid(@RequestParam Map<String, Object> map) {
		BookVo resultMap = bookService.selectbyid(map);	
		System.out.println(resultMap);
		ModelAndView mv = new ModelAndView();
		mv.addObject("book", resultMap);	
		mv.setViewName("/book/detail");
		return mv;
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public ModelAndView update(@RequestParam Map<String, Object> map) {
		// 업데이트 하고자 하는데이터를 Db에서 조회한후 가져와서 화면에 표시한다.
		
		ModelAndView mv = new ModelAndView("/book/update");
		BookVo resultMap = bookService.selectbyid(map);
		mv.addObject("book", resultMap);
		return mv;
	}
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView updatePost(@RequestParam Map<String, Object> map) {
		bookService.update(map);		
		ModelAndView mv = new ModelAndView("/book/detail");
//		mv.addObject("book",map);
		mv.setViewName("redirect:/list");
		return mv;
	}
	
	// 리스트
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam Map<String, Object> map) {
		List< Map<String, Object> > lists = new ArrayList<Map<String,Object>>();
		int start = Integer.valueOf( (String) map.get("page") );
		if(start == 1) {
			start = 0;
		}else {
			start = (start-1)*PERCOUNT+1;
		}
		map.put("start", start);		
		map.put("end", PERCOUNT);
		
		lists = bookService.lists(map);		
		ModelAndView mv = new ModelAndView("/book/list");
		mv.addObject("booklists", lists);
		
		// 검색조건에 대한 전체 데이터 건수
		int totalSize = bookService.totalcount(map);		  
		int pageCount = totalSize / PERCOUNT;
		if(totalSize % PERCOUNT != 0) {
			pageCount++;
		}		
		mv.addObject("pageCount", pageCount);
		mv.addObject("page", map.get("page"));
		return mv;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView deleteItem(@RequestParam Map<String, Object> map) {
		bookService.deleteById(map);
		ModelAndView mv = new ModelAndView("redirect:/list");
		return mv;
	}
	
	
	
}








