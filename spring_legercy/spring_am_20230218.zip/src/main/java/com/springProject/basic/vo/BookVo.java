package com.springProject.basic.vo;

import java.util.Date;

public class BookVo {
	private int book_id;  
	private String title; 
	private int price; 
	private Date create_dt; 
	private String category;
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Date getCreate_dt() {
		return create_dt;
	}
	public void setCreate_dt(Date create_dt) {
		this.create_dt = create_dt;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "BookVo [book_id=" + book_id + ", title=" + title + ", price=" + price + ", create_dt=" + create_dt
				+ ", category=" + category + "]";
	}
	
	
}
