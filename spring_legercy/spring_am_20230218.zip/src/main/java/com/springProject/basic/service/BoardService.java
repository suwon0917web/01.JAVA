package com.springProject.basic.service;

import java.util.List;

import com.springProject.basic.vo.BoardVo;
import com.springProject.basic.vo.FileInfoVo;

public interface BoardService {

	List<BoardVo> getBoardList();

	int insert(BoardVo vo);

	void fileInsert(List<FileInfoVo> savedFileNames);

}
