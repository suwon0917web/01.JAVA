package com.springProject.basic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BookController {

	private static final Logger logger = LoggerFactory.getLogger(BookController.class);
	
	@RequestMapping(value = "/create", method = RequestMethod.GET
			)
	public ModelAndView create() {
		logger.info("컨트롤러 호출 get");
		ModelAndView modelandview = new ModelAndView("book/create");		
		return modelandview;		
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ModelAndView createPost() {
		logger.info("컨트롤러 호출 post");	
		ModelAndView modelandview = new ModelAndView("book/create");		
		return modelandview;
		
	}
}
