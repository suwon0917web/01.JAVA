package com.springProject.basic.service;

import com.springProject.basic.vo.MemberInfoVo;

public interface MemberService {

	void insert(MemberInfoVo vo);

	MemberInfoVo getMemberById(String id);

}
