package com.springProject.basic.vo;

import java.util.Date;

public class BoardVo {
	private int b_no;
    private String b_id;
    private Date create_dt;
    private int b_view;    
    private String b_category;
    private String b_title;
    private String b_content;
	public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public String getB_id() {
		return b_id;
	}
	public void setB_id(String b_id) {
		this.b_id = b_id;
	}
	public Date getCreate_dt() {
		return create_dt;
	}
	public void setCreate_dt(Date create_dt) {
		this.create_dt = create_dt;
	}
	public int getB_view() {
		return b_view;
	}
	public void setB_view(int b_view) {
		this.b_view = b_view;
	}
	public String getB_category() {
		return b_category;
	}
	public void setB_category(String b_category) {
		this.b_category = b_category;
	}
	public String getB_title() {
		return b_title;
	}
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	public String getB_content() {
		return b_content;
	}
	public void setB_content(String b_content) {
		this.b_content = b_content;
	}
	@Override
	public String toString() {
		return "BoardVo [b_no=" + b_no + ", b_id=" + b_id + ", create_dt=" + create_dt + ", b_view=" + b_view
				+ ", b_category=" + b_category + ", b_title=" + b_title + ", b_content=" + b_content + "]";
	}
    
}
