package com.springProject.basic.controller;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.springProject.basic.service.MemberService;
import com.springProject.basic.vo.MemberInfoVo;

@Controller
public class MemberController {
	@Autowired
	private MemberService memberService; 
	
	// 로그인 폼 호출
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login() {		
		ModelAndView mv = new ModelAndView("/member/login");
		return mv;
	}
	
	// 회원가입폼 load
	@RequestMapping(value = "/registerMember", method = RequestMethod.GET)
	public ModelAndView registerMember() {		
		ModelAndView mv = new ModelAndView("/member/register");
		return mv;
	}
	
	// 회원가입폼에서 데이터 받아서 회원가입
	@RequestMapping(value = "/registerMember", method = RequestMethod.POST)
	public ModelAndView registerMemberPost(MemberInfoVo vo) {		
		memberService.insert(vo);		
		ModelAndView mv = new ModelAndView("redirect:/");
		return mv;
	}
	
	@ResponseBody
	@RequestMapping(value = "/duplicateId")
	public JSONArray duplicateId(String data) {		 
		ObjectMapper mapper = new ObjectMapper();
		JSONArray result = new JSONArray();		
		try {
			JSONArray jsonarray = mapper.readValue(data, JSONArray.class);
			HashMap ja =  (HashMap) jsonarray.get(0);
			String id = (String)ja.get("id");
			// 모델을 호출해서 아이디로 멤버 검색
			MemberInfoVo vo = memberService.getMemberById(id);
			if(vo!=null)
				result.add(true);
			else
				result.add(false);
			
		} catch (Exception e) {
			e.printStackTrace();
			result.add(false);
		}		
		return result;
	}
	

}
