package com.springProject.basic.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springProject.basic.dao.MemberDao;
import com.springProject.basic.vo.MemberInfoVo;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberDao memberDao;
	
	@Override	
	public void insert(MemberInfoVo vo) {
		memberDao.insert(vo);
	}

	@Override
	public MemberInfoVo getMemberById(String id) {		
		return memberDao.getMemberById(id);
	}

}
