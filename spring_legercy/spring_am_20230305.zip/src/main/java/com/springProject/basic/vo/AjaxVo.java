package com.springProject.basic.vo;

import lombok.Data;

@Data
public class AjaxVo {
	private int value1;
	private String value2;
}
