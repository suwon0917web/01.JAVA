package com.springProject.basic.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.ResultMap;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.springProject.basic.service.KaKaoLoginService;
import com.springProject.basic.service.MemberService;

@Controller
public class KakaoLoginController {
	private static final Logger logger = LoggerFactory.getLogger(KakaoLoginController.class);

	@Autowired
	private KaKaoLoginService kakaologinservice;
	
	// 사용자가 로그인 요청시 토큰발행을 위해 요청
	@ResponseBody
	@RequestMapping(value = "/member/kakaologin")
	public void kakaoLogin(@RequestParam String code, HttpServletRequest req){
		logger.info("########## kakaologin ########## ");
		HttpSession session = req.getSession();
		Map<String, Object> resultMap = null;
		try {
			// 토큰 얻어오기
			String access_token = kakaologinservice.getKakaoToken(code);
			// 사용자 정보 읽어오기
			resultMap = kakaologinservice.getKakaoUserInfo(access_token);
			session.setAttribute("access_token", access_token);
			
		} catch (Exception e) {
			e.printStackTrace();
		}	
		System.out.println(resultMap);
	}

	// 카카오 로그인 요청
	@RequestMapping(value = "/kakaologin", method = RequestMethod.GET)
	public ModelAndView kakaologin(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("/member/kakaologin");
		return mv;
	}
	
	// web 에서 카카오 로그아웃 요청
//	@ResponseBody
//	@RequestMapping(value = "/kakaologoutbefore", method = RequestMethod.GET)
//	public void kakaologoutbefore(HttpServletRequest req) {
//		HttpSession session = req.getSession();
//		String access_token = (String)session.getAttribute("access_token");
//		try {
//			kakaologinservice.logout(access_token);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}	
	
	// 카카오에서 호출해주는 경로
	@RequestMapping(value = "/kakaologout", method = RequestMethod.GET)
	public ModelAndView kakaologout(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("redirect:/kakaologin");
		return mv;
	}

}
