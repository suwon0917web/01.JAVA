package com.springProject.basic.vo;

import lombok.Data;

@Data
public class FileInfoVo {
	private int f_id;
	private int b_no;
	private String f_path;
	private String f_fileName;
	private String f_realFileName;	
}
