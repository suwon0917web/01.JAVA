package com.springProject.basic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springProject.basic.dao.BookDao;
import com.springProject.basic.dao.CommonDao;
import com.springProject.basic.vo.CommonVo;

@Service
public class CommonServiceImpl implements CommonService {

	@Autowired
	CommonDao commonDao;
	
	@Override
	public List<CommonVo> select(String groupcode) {		
		return commonDao.select(groupcode);
	}

}
