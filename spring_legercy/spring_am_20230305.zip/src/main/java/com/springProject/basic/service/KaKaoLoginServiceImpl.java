package com.springProject.basic.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Service;

@Service
public class KaKaoLoginServiceImpl implements KaKaoLoginService {	
	@Override
	public String getKakaoToken(String code) throws Exception {		
		String host = "https://kauth.kakao.com/oauth/token";		
		URL url = new URL(host);
		HttpURLConnection urlconection = (HttpURLConnection) url.openConnection();
		urlconection.setRequestMethod("POST");
		urlconection.setDoOutput(true);
		BufferedWriter bw = null;
		BufferedReader br = null;
		String accecc_token = null;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(urlconection.getOutputStream()));
			StringBuffer sb = new StringBuffer();
			sb.append("grant_type=authorization_code");
			sb.append("&client_id=cbda575e29a03219376c9122aac6e811");
			sb.append("&redirect_uri=http://localhost:8080/member/kakaologin");
			sb.append("&code=" + code);
			bw.write(sb.toString());
			bw.flush();
			System.out.println(sb.toString());
			int responseCode = urlconection.getResponseCode();
			System.out.println("responseCode = "+responseCode);
			// 응답내용 읽기 token 발급받기
			br = new BufferedReader(new InputStreamReader(urlconection.getInputStream()));
			String line = "";
			String result = "";
			while ((line = br.readLine()) != null) {
				result += line;
			}
			JSONParser parser = new JSONParser();
			JSONObject obj = (JSONObject) parser.parse(result);			
			accecc_token = (String)obj.get("access_token");			
		} finally {
			if (bw != null)
				bw.close();
			if (br != null)
				br.close();
		}
		return accecc_token;
	}

	@Override
	public Map<String, Object> getKakaoUserInfo(String accecc_token) throws Exception {
		String host = "https://kapi.kakao.com/v2/user/me";
		URL url = new URL(host);
		HttpURLConnection urlconection = (HttpURLConnection) url.openConnection();
		urlconection.setRequestMethod("GET");
		urlconection.setRequestProperty("Authorization", "Bearer "+accecc_token);
		System.out.println(urlconection.toString());
		int responseCode =  urlconection.getResponseCode();
		System.out.println("responseCode = "+responseCode);
		BufferedReader br = null;
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {			
			br = new BufferedReader(new InputStreamReader(urlconection.getInputStream()));
			String line = "";
			String result = "";
			while ((line = br.readLine()) != null) {
				result += line;
			}
			JSONParser parser = new JSONParser();
			JSONObject obj = (JSONObject) parser.parse(result);
			JSONObject kakao_acount = (JSONObject)obj.get("kakao_account");
			JSONObject profile =  (JSONObject)kakao_acount.get("profile");
			String email = (String)kakao_acount.get("email");
			String nickname = (String)profile.get("nickname");
			resultMap.put("email", email);
			resultMap.put("nickname", nickname);		
			
		} finally {			
			if (br != null)
				br.close();
		}
		return resultMap;
	}
/*
curl -v -X POST "https://kapi.kakao.com/v1/user/logout" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" 
 */
	@Override
	public void logout(String accecc_token) throws Exception {		
		String host = "https://kapi.kakao.com/v1/user/logout";
//		host += REST_API_KEY;
//		host += "&logout_redirect_uri=";
//		host += LOGOUT_REDIRECT_URI;
		URL url = new URL(host);
		HttpURLConnection urlconection = (HttpURLConnection) url.openConnection();
		urlconection.setRequestMethod("GET");
		urlconection.setRequestProperty("Authorization", "Bearer "+accecc_token);
		System.out.println(urlconection.toString());
		int responseCode =  urlconection.getResponseCode();
		System.out.println("responseCode = "+responseCode);
	}

}
