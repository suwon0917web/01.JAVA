package com.springProject.basic.vo;

import java.util.Date;

public class CommentVo {
	private int c_no; // '아이디',
    private int c_postno; // '뎃글번호(부모의 번호)',
    private String c_id; // '작성자',
    private Date create_dt; // '작성일',
    private String c_content; // '뎃글내용',
	public int getC_no() {
		return c_no;
	}
	public void setC_no(int c_no) {
		this.c_no = c_no;
	}
	public int getC_postno() {
		return c_postno;
	}
	public void setC_postno(int c_postno) {
		this.c_postno = c_postno;
	}
	public String getC_id() {
		return c_id;
	}
	public void setC_id(String c_id) {
		this.c_id = c_id;
	}
	public Date getCreate_dt() {
		return create_dt;
	}
	public void setCreate_dt(Date create_dt) {
		this.create_dt = create_dt;
	}
	public String getC_content() {
		return c_content;
	}
	public void setC_content(String c_content) {
		this.c_content = c_content;
	}
	@Override
	public String toString() {
		return "CommentVo [c_no=" + c_no + ", c_postno=" + c_postno + ", c_id=" + c_id + ", create_dt=" + create_dt
				+ ", c_content=" + c_content + "]";
	}
    
}
