package com.springProject.basic.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springProject.basic.vo.BoardVo;

@Repository
public class BoardDao {

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public void insert(BoardVo vo) {
		sqlSessionTemplate.insert("board.insert", vo);
		
	}

	public List<BoardVo> getBoardList() {		
		return sqlSessionTemplate.selectList("board.getBoardList");
	}
}
