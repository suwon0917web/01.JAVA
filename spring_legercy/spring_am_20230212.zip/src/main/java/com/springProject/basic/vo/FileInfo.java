package com.springProject.basic.vo;

public class FileInfo {
	private int f_id;
	private String encriptFileName;
	private String saveFolder;
	private String originFileName;
	public int getF_id() {
		return f_id;
	}
	public void setF_id(int f_id) {
		this.f_id = f_id;
	}
	public String getEncriptFileName() {
		return encriptFileName;
	}
	public void setEncriptFileName(String encriptFileName) {
		this.encriptFileName = encriptFileName;
	}
	public String getSaveFolder() {
		return saveFolder;
	}
	public void setSaveFolder(String saveFolder) {
		this.saveFolder = saveFolder;
	}
	public String getOriginFileName() {
		return originFileName;
	}
	public void setOriginFileName(String originFileName) {
		this.originFileName = originFileName;
	}
	@Override
	public String toString() {
		return "FileInfo [f_id=" + f_id + ", encriptFileName=" + encriptFileName + ", saveFolder=" + saveFolder
				+ ", originFileName=" + originFileName + "]";
	}
	
}
