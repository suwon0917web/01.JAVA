package com.springProject.basic.controller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.springProject.basic.service.FileUpDwonload;

@Controller
public class FileUploadController {
	@Autowired
	ServletContext servletContext;
	
	@RequestMapping(value = "/upload", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView mv = new ModelAndView("imageupload/upload");
		return mv;
	}
	
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public ModelAndView createPoist(
			@RequestParam("title") String name,
			@RequestParam("filename") MultipartFile[] file) throws IllegalStateException, IOException {
		
		FileUpDwonload.saveFileFromUI(servletContext, file);		
		
		ModelAndView mv = new ModelAndView("imageupload/upload");
		return mv;
	}
	
	
	@RequestMapping(value = "/imageDownload", method = RequestMethod.POST)	
	public ModelAndView fileDownLoad(String data, HttpServletResponse response) {		
		return new ModelAndView("fileDownLoadView", "downloadFile", null);
	}

	
}
