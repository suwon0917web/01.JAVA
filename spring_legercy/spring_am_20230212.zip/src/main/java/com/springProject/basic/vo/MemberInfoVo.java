package com.springProject.basic.vo;

import java.util.Date;

public class MemberInfoVo {
	private String m_id;
    private String m_pw;
    private Date create_dt;
    private String m_type; // '1 관리자 0 회원',
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	public String getM_pw() {
		return m_pw;
	}
	public void setM_pw(String m_pw) {
		this.m_pw = m_pw;
	}
	public Date getCreate_dt() {
		return create_dt;
	}
	public void setCreate_dt(Date create_dt) {
		this.create_dt = create_dt;
	}
	public String getM_type() {
		return m_type;
	}
	public void setM_type(String m_type) {
		this.m_type = m_type;
	}
	@Override
	public String toString() {
		return "MemberInfoVo [m_id=" + m_id + ", m_pw=" + m_pw + ", create_dt=" + create_dt + ", m_type=" + m_type
				+ "]";
	}
    
}
