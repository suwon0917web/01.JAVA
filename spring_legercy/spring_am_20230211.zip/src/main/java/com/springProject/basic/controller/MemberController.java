package com.springProject.basic.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.springProject.basic.service.MemberService;
import com.springProject.basic.vo.MemberInfoVo;

@Controller
public class MemberController {
	@Autowired
	private MemberService memberService;

	// 로그인 폼 호출
	// 이미 로그인 되어 있다면.. logout 버튼 동적으로 만들어 준다.
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("/member/login");
		HttpSession session = req.getSession();
		// 이미 로그인 한 상태인지 판단하고
		// 로그인을 했으면 특정 값을 셋팅해서 화면으로 전달해서 화면서는 그 값이 있으면
		// logout 버튼이나 기능을 활성화 한다
		mv.addObject("isLogine", false);
		if (session != null && session.getAttribute("loginId") != null) {
			mv.addObject("isLogine", true);
		}
		System.out.println("************ " + mv);
		return mv;
	}

	// 로그인 프로세스
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView loginPost(MemberInfoVo vo, HttpServletRequest req) {
		HttpSession session = req.getSession();
		System.out.println("####### session = " + session);
		if (session != null && session.getAttribute("loginId") != null) {
			session.invalidate();
		} else {
			vo.setM_type("0"); // 일반적인 상황에서 회원로그인은 회원만 가능
			MemberInfoVo resultVo = memberService.getMemberById(vo.getM_id());
			// 로그인 성공
			if (resultVo != null && resultVo.getM_pw().equals(vo.getM_pw())) {
				session.setAttribute("loginId", resultVo.getM_id());
				// 성공시 보여줄 페이지로 이동
			}
		}
		ModelAndView mv = new ModelAndView("redirect:/login");
		return mv;
	}

	// 회원가입폼 load
	@RequestMapping(value = "/registerMember", method = RequestMethod.GET)
	public ModelAndView registerMember() {
		ModelAndView mv = new ModelAndView("/member/register");
		return mv;
	}

	// 회원가입폼에서 데이터 받아서 회원가입
	@RequestMapping(value = "/registerMember", method = RequestMethod.POST)
	public ModelAndView registerMemberPost(MemberInfoVo vo) {
		memberService.insert(vo);
		ModelAndView mv = new ModelAndView("redirect:/");
		return mv;
	}

	@ResponseBody
	@RequestMapping(value = "/duplicateId")
	public JSONArray duplicateId(String data) {
		ObjectMapper mapper = new ObjectMapper();
		JSONArray result = new JSONArray();
		try {
			JSONArray jsonarray = mapper.readValue(data, JSONArray.class);
			HashMap ja = (HashMap) jsonarray.get(0);
			String id = (String) ja.get("id");
			// 모델을 호출해서 아이디로 멤버 검색
			MemberInfoVo vo = memberService.getMemberById(id);
			if (vo != null)
				result.add(true);
			else
				result.add(false);

		} catch (Exception e) {
			e.printStackTrace();
			result.add(false);
		}
		return result;
	}

}
