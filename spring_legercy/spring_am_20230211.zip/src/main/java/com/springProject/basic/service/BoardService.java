package com.springProject.basic.service;

import java.util.List;

import com.springProject.basic.vo.BoardVo;

public interface BoardService {

	List<BoardVo> getBoardList();

	void insert(BoardVo vo);

}
