package com.springProject.basic.controller;

import java.io.File;
import java.nio.file.attribute.FileTime;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUpload;
import org.apache.commons.fileupload.FileUploadException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.springProject.basic.service.BoardService;
import com.springProject.basic.vo.BoardVo;

@Controller
public class BoardController {

	@Autowired  // 생성된 bean(스프링 컨테이너가 만들어주는 객체)을 연결해 주는 어노테이션
	BoardService boardService;
	
	@RequestMapping(value = "/board", method = RequestMethod.GET)
	public ModelAndView board() {
		ModelAndView mv = new ModelAndView("board/board");
		List<BoardVo> boardlist = boardService.getBoardList();
		mv.addObject("boardlist", boardlist);
		return mv;
	}
	// 게시판 작성 화면 호출
	@RequestMapping(value = "/boardwrite", method = RequestMethod.GET)
	public ModelAndView boardwrite() {
		List<BoardVo> boardlist = boardService.getBoardList();		
		ModelAndView mv = new ModelAndView("board/boardwrite");		
		return mv;
	}
	
	// 게시판 작성 후 게시판 화면으로 돌아감
	@RequestMapping(value = "/boardwrite", method = RequestMethod.POST)
	public ModelAndView boardwritePoist(
			BoardVo vo, HttpServletRequest req
			 ) throws FileUploadException {
		FileUpload upload = new FileUpload();
		List items = upload.parseRequest(req);
		Iterator params =  items.iterator();
		while(params.hasNext()) {
			FileItem item = (FileItem)params.next();
			if(!item.isFormField()) {
				System.out.println(item.getName());
			}
		}
		
		ModelAndView mv = new ModelAndView();		
//		HttpSession session = req.getSession();
//		if(session !=null && session.getAttribute("loginId") != null) {
//			vo.setB_id((String)session.getAttribute("loginId"));
//			vo.setB_category("1");
//			// 게시글 insert
//			boardService.insert(vo);
//			
//			mv.setViewName("redirect:/board");  // 컨트롤러 호출
//		}
//		else {
//			mv.setViewName("redirect:/login");  // 컨트롤러 호출
//		}
		
		return mv;
	}
}
