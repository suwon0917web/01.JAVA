package com.springProject.basic.vo;

import java.util.Date;

import lombok.Data;

@Data
public class BoardVo {
	private int b_no;
    private String b_id;
    private Date create_dt;
    private int b_view;    
    private String b_category;
    private String b_title;
    private String b_content;
    private String b_file;    
}
