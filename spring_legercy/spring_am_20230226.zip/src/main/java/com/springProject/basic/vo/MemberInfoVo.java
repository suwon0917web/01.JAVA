package com.springProject.basic.vo;

import java.util.Date;

import lombok.Data;

@Data
public class MemberInfoVo {
	private String m_id;
    private String m_pw;
    private Date create_dt;
    private String m_type; // '1 관리자 0 회원',    
}