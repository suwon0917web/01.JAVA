package com.springProject.basic.vo;

import java.util.Date;

import lombok.Data;

@Data
public class BookVo {
	private int book_id;  
	private String title; 
	private int price; 
	private Date create_dt; 
	private String category;
}
