package com.springProject.basic.service;

import java.util.List;
import java.util.Map;

public interface BookService {
	String insert(Map<String, Object> map);
	Map<String, Object> selectbyid(Map<String, Object> map);
	void update(Map<String, Object> map);
	List<Map<String, Object>> lists();
	List<Map<String, Object>> lists(Map<String, Object> map);	
}
