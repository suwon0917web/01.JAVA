package com.springProject.basic.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springProject.basic.dao.BookDao;

@Service
public class BookServiceImpl implements BookService {
	
	@Autowired
	BookDao bookDao;

	// map으로 전달받은 데이터를 insert 하기위해 해당정보를 DAO로 전달한다.
	// insert 기능을 가진 DAO
	// map 에 들어 있는key? title, price, category 
	@Override
	public String insert(Map<String, Object> map) {
		int result = bookDao.insert(map);
		if(result == 1)
			return map.get("book_id").toString();
		return null;
		
	}

	@Override
	public Map<String, Object> selectbyid(Map<String, Object> map) {
		return bookDao.selectbyid(map);		 
	}

	@Override
	public void update(Map<String, Object> map) {
		bookDao.update(map);
		
	}

	@Override
	public List<Map<String, Object>> lists() {		
		return bookDao.getlists();
	}

	@Override
	public List<Map<String, Object>> lists(Map<String, Object> map) {		
		return bookDao.getlists(map);
	}
}
