package com.springProject.basic.service;

import java.util.Map;

public interface KaKaoLoginService {
	String REST_API_KEY = "cbda575e29a03219376c9122aac6e811";
	String REDIRECT_URI	="http://localhost:80/member/kakaologin";
	String LOGOUT_REDIRECT_URI = "http://localhost:80/kakaologout";
	String getKakaoToken(String code)throws Exception;
	Map<String, Object> getKakaoUserInfo(String access_token) throws Exception;
	void logout(String accecc_token) throws Exception;
}
