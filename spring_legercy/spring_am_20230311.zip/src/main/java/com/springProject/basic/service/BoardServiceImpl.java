package com.springProject.basic.service;

import java.io.File;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springProject.basic.dao.BoardDao;
import com.springProject.basic.vo.BoardVo;
import com.springProject.basic.vo.CommentVo;
import com.springProject.basic.vo.FileInfoVo;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	BoardDao boardDao;
	
	
	@Override
	public List<BoardVo> getBoardList() {		
		return boardDao.getBoardList();
	}

	@Override
	public int insert(BoardVo vo) {
		return boardDao.insert(vo);
		
	}

	@Override
	public void fileInsert(List<FileInfoVo> savedFileNames) {
		boardDao.fileInsert(savedFileNames);
		
	}

	@Override
	public List<CommentVo> selectComment(int boardId) {		
		List<CommentVo> lists = boardDao.selectComment(boardId);
		// 엔터를 html 태그로 변경
		for (CommentVo commentVo : lists) {
			commentVo.setC_content( commentVo.getC_content().replace("\r\n", "<br>") );
		}
		return lists;
	}

	@Override
	public void insertComment(CommentVo vo) {
		boardDao.insertComment(vo);
		
	}

	@Override
	public BoardVo selectById(int b_no) {
		// TODO Auto-generated method stub
		// 엔터를 html 태그로 변경
		BoardVo vo = boardDao.selectById(b_no);		
		vo.setB_content( vo.getB_content().replace("\r\n", "<br>") );
		return vo;
	}

	@Override
	public List<FileInfoVo> selectReplyByIdFiles(Integer b_no) {
		List<FileInfoVo> files = boardDao.selectReplyByIdFiles(b_no);
		String pattern = Pattern.quote(System.getProperty("file.separator"));
		for (FileInfoVo fileInfoVo : files) {			
			String[] temp = fileInfoVo.getF_path().split(pattern);
			String str = "";
			for (int i = 3; i > 0; i--) {
				str += temp[temp.length-i]+File.separator;
			}
			str+=fileInfoVo.getF_fileName();
			System.out.println(str); // 디버깅용
			fileInfoVo.setF_path(str); // 화면에서 사용하기 위해서
		}
		return files;
	}

}
