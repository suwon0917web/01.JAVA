package com.springProject.basic.vo;

import lombok.Data;

@Data
public class CommonVo {
	private  String groupcode;
	private  String code;
	private  String name;
}
