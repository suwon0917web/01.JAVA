package com.springProject.basic.service;

import java.util.List;
import java.util.Map;

import com.springProject.basic.vo.BookVo;

public interface BookService {
	String insert(Map<String, Object> map);
	BookVo selectbyid(Map<String, Object> map);
	void update(Map<String, Object> map);
	List<Map<String, Object>> lists();
	List<Map<String, Object>> lists(Map<String, Object> map);
	void deleteById(Map<String, Object> map);
	int totalcount(Map<String, Object> map);	
}
