package com.springProject.basic.vo;

import lombok.Data;

@Data
public class CommentVo {
	private int c_no; // '아이디',
    private int c_postno; // '뎃글번호(부모의 번호)',
    private String c_id; // '작성자',
    private String create_dt; // '작성일',
    private String c_content; // '뎃글내용',
}
