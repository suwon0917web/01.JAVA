package com.springProject.basic.dao;

import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springProject.basic.vo.MemberInfoVo;

@Repository
public class MemberDao {	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	public void insert(MemberInfoVo vo) {
		sqlSessionTemplate.insert("memberInfo.insert", vo);		
	}
	public MemberInfoVo getMemberById(String id) {		
		return sqlSessionTemplate.selectOne("memberInfo.getMemberById", id);
	}

}
