package com.springProject.basic.service;

import java.util.List;

import com.springProject.basic.vo.BoardVo;
import com.springProject.basic.vo.CommentVo;
import com.springProject.basic.vo.FileInfoVo;

public interface BoardService {

	List<BoardVo> getBoardList();

	int insert(BoardVo vo);

	void fileInsert(List<FileInfoVo> savedFileNames);

	List<CommentVo> selectComment(int boardId);

	void insertComment(CommentVo vo);

	BoardVo selectById(int b_no);

	List<FileInfoVo> selectReplyByIdFiles(Integer valueOf);

}
