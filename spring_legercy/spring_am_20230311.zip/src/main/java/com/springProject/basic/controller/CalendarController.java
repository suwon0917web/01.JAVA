package com.springProject.basic.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CalendarController {

	@RequestMapping(value = "/calendar", method = RequestMethod.GET)
	public ModelAndView calendar() {
		ModelAndView mv = new ModelAndView("calendar/calendar");
		return mv;
		
	}
	@RequestMapping(value = "/calendar2", method = RequestMethod.GET)
	public ModelAndView calendar2() {
		ModelAndView mv = new ModelAndView("calendar/calendar2");
		return mv;
		
	}
}
