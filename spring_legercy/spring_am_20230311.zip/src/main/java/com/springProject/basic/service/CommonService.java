package com.springProject.basic.service;

import java.util.List;

import com.springProject.basic.vo.CommonVo;

public interface CommonService {

	List<CommonVo> select(String groupcode);

}
