package com.springProject.basic.controller;

import java.util.HashMap;
import java.util.List;

import org.json.simple.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.springProject.basic.service.CommonService;
import com.springProject.basic.vo.CommonVo;

@Controller
public class CommonController {
	private static final Logger logger = LoggerFactory.getLogger(BookController.class);
	
	@Autowired  // 생성된 bean(스프링 컨테이너가 만들어주는 객체)을 연결해 주는 어노테이션	
	CommonService commonService;
	
//	private JSONArray convertJsonToList(List<CommonVo> lists) {
//		JSONArray json = new JSONArray();
//		for (CommonVo vo : lists) {
//			
//		}
//	}
	
	
	
	@RequestMapping(value = "/commoncode", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView mv = new ModelAndView("common/common");
		return mv;
	}
	
	
	@ResponseBody
	@RequestMapping(value = "/getcommoncode")
	public JSONArray ajaxTest(String data) {		
//		System.out.println("data : " + data);
		JSONArray returnjsonArray = new JSONArray();
		
		JSONArray jsonarray = new JSONArray();
		ObjectMapper mapper = new ObjectMapper();
		try {			
			jsonarray = mapper.readValue(data, JSONArray.class);
			for (int i = 0; i < jsonarray.size(); i++) {
				HashMap ja =  (HashMap) jsonarray.get(i);
				System.out.println(ja.get("groupcode"));
				List<CommonVo> commons 
					= commonService.select((String)ja.get("groupcode"));
				returnjsonArray.add(commons);
				System.out.println("commons :" + commons);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return returnjsonArray;
	}
	
}
