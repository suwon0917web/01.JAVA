package com.springProject.basic.service;

import java.util.Map;

public interface BookService {
	String insert(Map<String, Object> map);
	Map<String, Object> selectbyid(Map<String, Object> map);
}
