package com.springProject.basic.dao;

import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BookDao {
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public int insert(Map<String, Object> map) {
		return sqlSessionTemplate.insert("book.insert",map);
	}
	
	public Map<String, Object> selectbyid(Map<String, Object> map){
		return sqlSessionTemplate.selectOne("book.selectbyid",map);
	}
}