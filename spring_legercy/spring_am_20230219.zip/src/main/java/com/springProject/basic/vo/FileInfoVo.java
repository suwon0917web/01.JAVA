package com.springProject.basic.vo;

public class FileInfoVo {
	private int f_id;
	private int b_no;
	private String f_path;
	private String f_fileName;
	private String f_realFileName;
	
	
	public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public int getF_id() {
		return f_id;
	}
	public void setF_id(int f_id) {
		this.f_id = f_id;
	}
	public String getF_path() {
		return f_path;
	}
	public void setF_path(String f_path) {
		this.f_path = f_path;
	}
	public String getF_fileName() {
		return f_fileName;
	}
	public void setF_fileName(String f_fileName) {
		this.f_fileName = f_fileName;
	}
	public String getF_realFileName() {
		return f_realFileName;
	}
	public void setF_realFileName(String f_realFileName) {
		this.f_realFileName = f_realFileName;
	}
	@Override
	public String toString() {
		return "FileInfoVo [f_id=" + f_id + ", b_no=" + b_no + ", f_path=" + f_path + ", f_fileName=" + f_fileName
				+ ", f_realFileName=" + f_realFileName + "]";
	}
	
	
}
