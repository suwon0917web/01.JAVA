package datatype;
// 기본타입을 객체로 표현하는 방법 또는 지원
// 감싼다 - wrapper --> wrapper class
public class Datatype04 {

	public static void main(String[] args) {
		Integer num = 0;
		Short sh = 0;
		Double d = 0.0;
//		Float f = (float) 0.0;
		Float f = 0.0f;
		Long l = 0L;
		System.out.println(num);		
	}

}
