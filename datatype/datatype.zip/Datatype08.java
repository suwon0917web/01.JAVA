package datatype;
//데이터 타입 review
public class Datatype08 {

	public static void main(String[] args) {
		/*
		 * 변수생성(정수,실수,문자열,불)
		 * 형변환(type casting) - 자동 (primitive 타입간의 작은->큰걸로)/수동(큰거->작은, 클래스타입) 
		 * 리터럴 - 글자그대로 변수가 되는
		 * primitive 타입에 대한 래퍼클래스 - Inteager, Char, Double..... 
		 * 문자열 포멧팅  %d %f  %.2f  %s
		 * 문자열의 내장함수 
		 * 		equals	  			-같은지 비교
		 * 		indexOF
		 * 		contains
		 * 		charAt
		 * 		replace
		 * 		replaceAll
		 * 		substring
		 * 		toUpperCase()
		 * 		split
		 * 		StringBuffer
		 */
	}

}







