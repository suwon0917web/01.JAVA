package datatype;

public class Excercise_ListMapSet01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
